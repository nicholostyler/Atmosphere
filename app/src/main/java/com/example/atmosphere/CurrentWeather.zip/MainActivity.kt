package com.example.atmosphere

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarColors
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ComposeCompilerApi
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.Log
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.createGraph
import coil3.compose.AsyncImage
import coil3.compose.SubcomposeAsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.util.DebugLogger
import com.example.atmosphere.ui.theme.AtmosphereTheme
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import kotlin.text.format
import kotlin.text.replace

data class BottomNavItem(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val route: String)
// Data class to represent a single hourly forecast item
data class HourlyForecastItem(
    val timestamp: String, // Unix timestamp for the hour
    val weatherIconUrl: String,
    val temperature: Int
) {

}
data class WeatherDay(
    val date: String,
    val weatherIconResId: Int, // Resource ID for the weather icon (e.g., R.drawable.ic_sunny)
    val lowTemp: Int,
    val highTemp: Int
)

@Composable
fun WeatherForecastCard(weatherDay: WeatherDay) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Date on the left
            Text(
                text = weatherDay.date,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(0.7f) // Give more weight to the date
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Weather Icon
            Image(
                painter = painterResource(id = weatherDay.weatherIconResId),
                contentDescription = "Weather Icon",
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            // Low Temperature
            Text(
                text = "${weatherDay.lowTemp}°",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Progress Bar (representing temperature range)
            val temperatureRange = weatherDay.highTemp - weatherDay.lowTemp
            val progress = if (temperatureRange > 0) {
                (weatherDay.highTemp - weatherDay.lowTemp).toFloat() / 30f // Assuming a max range for scale, adjust as needed
            } else {
                0f
            }

            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier
                    .weight(1f) // Fills available space
                    .height(8.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primaryContainer
            )

            Spacer(modifier = Modifier.width(8.dp))

            // High Temperature
            Text(
                text = "${weatherDay.highTemp}°",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun WeeklyForecastList()
{
    // Generate dummy data for 7 days
    val weatherData = remember {
        val today = LocalDate.now()
        List(7) { i ->
            val date = today.plusDays(i.toLong())
            val formatter = DateTimeFormatter.ofPattern("EEE, MMM d") // e.g., Mon, May 24
            WeatherDay(
                date = date.format(formatter),
                weatherIconResId = when (i) {
                    0 -> R.drawable.sunny // Replace with your actual drawables
                    1 -> R.drawable.sunny
                    2 -> R.drawable.sunny
                    3 -> R.drawable.sunny
                    4 -> R.drawable.sunny
                    5 -> R.drawable.sunny
                    else -> R.drawable.sunny
                },
                lowTemp = 15 + i, // Example low temps
                highTemp = 60 + i * 2 // Example high temps
            )
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(weatherData) { weatherDay ->
            WeatherForecastCard(weatherDay = weatherDay)
        }
    }
}

fun convertTo12HourFormat(hourString: String): String {
    return try {
        // Assume the string is just the hour, so append ":00" to match "HH:mm"
        val time24HourWithMinutes = "$hourString:00"
        val defaultLocale = java.util.Locale.getDefault()
        val inputFormat = SimpleDateFormat("HH:mm", defaultLocale)
        val outputFormat = SimpleDateFormat("h:mm a", defaultLocale) // Or "h a" if you don't want ":00"

        val date = inputFormat.parse(time24HourWithMinutes)

        if (date != null) {
            outputFormat.format(date)
        } else {
            hourString // Fallback
        }
    } catch (e: Exception) {
        // Log.e("TimeFormat", "Error converting hour string: $hourString", e)
        hourString // Fallback
    }
}

@Composable
fun ProfileScreen() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(text = "Profile Screen", style = MaterialTheme.typography.headlineLarge)
    }
}

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(text = "Settings Screen", style = MaterialTheme.typography.headlineLarge)
    }
}

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AtmosphereTheme {
                val weatherViewModel: WeatherViewModel = viewModel() // Obtain ViewModel here
                weatherViewModel.fetchCurrentWeather(37.4220, -122.0841, "AIzaSyDuGUq0-LRTEVALchxzgi72mh70Nkt-YqQ")

                val navController = rememberNavController()
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Text("Cinnaminson, NJ")
                            },
                            colors = TopAppBarDefaults.topAppBarColors()
                        )
                    },
                ) { contentPadding ->
                    HomePage(contentPadding, weatherViewModel)


                }
            }
        }
    }

    @Composable
    fun HomePage(contentPadding: PaddingValues, viewModel: WeatherViewModel) { // contentPadding is passed from NavHost
        val sampleHourlyForecasts = remember {
            listOf(
                HourlyForecastItem("11", "https://maps.gstatic.com/weather/v1/sunny.png", 70),
                HourlyForecastItem("12", "https://maps.gstatic.com/weather/v1/sunny.png", 72),
                HourlyForecastItem("13", "https://maps.gstatic.com/weather/v1/sunny.png", 75),
                HourlyForecastItem("14", "https://maps.gstatic.com/weather/v1/sunny.png", 68),
                HourlyForecastItem("15", "https://maps.gstatic.com/weather/v1/sunny.png", 65),
                HourlyForecastItem("16", "https://maps.gstatic.com/weather/v1/sunny.png", 66),
                HourlyForecastItem("17", "https://maps.gstatic.com/weather/v1/sunny.png", 62),
            )
        }

        val currentWeatherData by viewModel.currentWeatherData.collectAsState()
        val errorMessage by viewModel.currentErrorMessage.collectAsState()
        val isLoading by viewModel.isLoading.collectAsState()

        if (isLoading) {
            if (currentWeatherData == null && errorMessage == null) {
                LaunchedEffect(Unit) { // Or trigger from a button click
                    viewModel.fetchCurrentWeather(37.4220, -122.0841, "AIzaSyDuGUq0-LRTEVALchxzgi72mh70Nkt-YqQ")
                }
            }

            if (currentWeatherData != null) {
                Log.d("Weather data not null ${currentWeatherData!!.weatherCondition.description}", "Weather data not null") // Re-use the WeatherDisplay Composable from previous example
            }

            else if (errorMessage != null) {
                Log.e("Error fetching weather data: $errorMessage", "Error fetching weather data")

            }
            else {
                Log.e("No data available", "No data available")

            }
        }


        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
                // .padding(contentPadding) // Apply here if not handled by a sub-container like CurrentConditionsView
            //horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (currentWeatherData != null)
            {
                CurrentConditionsView(
                    System.currentTimeMillis(),
                    currentWeatherData!!.temperature.degrees.toInt(),
                    currentWeatherData!!.weatherCondition.iconBaseUri + ".png",
                    75,
                    68,
                    currentWeatherData!!.weatherCondition.description.text,
                    currentWeatherData!!.feelsLikeTemperature.degrees.toInt())
            }
            else {
                CurrentConditionsView()
            }
            // This will now correctly take padding from its own Surface
            Spacer(modifier = Modifier.height(16.dp))
            HourlyForecastCard(hourlyForecasts = sampleHourlyForecasts) // Add the new card here
            Spacer(modifier = Modifier.height(16.dp))
            WeeklyForecastList()

        }
    }

    @Composable
    fun CurrentConditionsView(
        timestamp: Long = System.currentTimeMillis(),
        currentTemperature: Int = 72,
        weatherIconUrl: String = "https://maps.gstatic.com/weather/v1/flurries.png",
        highTemperature: Int = 75,
        lowTemperature: Int = 68,
        weatherDescription: String = "Partly Cloudy",
        feelsLikeTemperature: Int = 74
    ) {
        Surface(
            // Optional: Add a Surface for elevation or background
            modifier = Modifier
                .fillMaxWidth(),
            shape = RoundedCornerShape(12.dp), // Optional: Rounded corners
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween, // Distribute space
                verticalAlignment = Alignment.Top // Align content to the top of the row
            ) {
                // --- Left Column ---
                Column(
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(8.dp) // Space between items in this column
                ) {
                    Text(
                        text = "Updated: ${SimpleDateFormat("h:mm a").format(timestamp)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$currentTemperature°",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Log.d("IconDebug", "Loading icon from URL : $weatherIconUrl")
                        val imageLoader = LocalContext.current.imageLoader.newBuilder()
                            .logger(DebugLogger())
                            .build()
                        AsyncImage(
                            imageLoader = imageLoader,
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(weatherIconUrl)
                                .crossfade(true)
                                .build(),
                            placeholder = painterResource(R.drawable.cloudy),
                            error = painterResource(R.drawable.cloudy),
                            contentDescription = "Weather icon",
                        )
                        Log.d(imageLoader.toString(), "imageLoader")
                    }

                    Row {
                        Text(
                            text = "H: $highTemperature°",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "L: $lowTemperature°",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
// --- Right Column ---
                Column(
                    horizontalAlignment = Alignment.End, // Align text to the end (right)
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = weatherDescription,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.End // Ensure text aligns to the end
                    )
                    Text(
                        text = "Feels like $feelsLikeTemperature°",
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.End
                    )
                }
            }
        }
        }

    @Composable
    fun HourlyForecastCard(
        modifier: Modifier = Modifier,
        hourlyForecasts: List<HourlyForecastItem>
    ) {
        if (hourlyForecasts.isEmpty()) {
            // Optionally show a message or hide the card if there's no data
            Text("Hourly forecast data is not available.", modifier = modifier.padding(16.dp))
            return
        }

        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp), // Padding around the card
            shape = RoundedCornerShape(12.dp),
            ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Hourly Forecast",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()), // Enable horizontal scrolling
                    horizontalArrangement = Arrangement.spacedBy(16.dp) // Space between each hourly item
                ) {
                    hourlyForecasts.forEach { forecastItem ->
                        HourlyForecastItemView(item = forecastItem)
                    }
                }
            }
        }
    }

    @Composable
    fun HourlyForecastItemView(
        modifier: Modifier = Modifier,
        item: HourlyForecastItem
    ) {
        Column(
            modifier = modifier.padding(vertical = 4.dp), // Small vertical padding for each item
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp) // Space between elements in the column
        ) {
            Text(
                text = convertTo12HourFormat(item.timestamp),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(item.weatherIconUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Weather icon for ${convertTo12HourFormat(item.timestamp)}" , // Be descriptive
                modifier = Modifier.size(36.dp) // Adjust icon size as needed
            )
            Text(
                text = "${item.temperature}°",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }


    @Composable
    fun WeekView() {
        Text("Week View")
    }

    @Composable
    fun SettingsView() {
        Text("Settings View")
    }

    @Preview(showBackground = true, widthDp = 380)
    @Composable
    fun CurrentConditionsPreview() { // Renamed for clarity, was GreetingPreview
        AtmosphereTheme {
            MainActivity().CurrentConditionsView() // This might not be ideal if it relies on MainActivity state not available in preview
        }
    }

    @Preview(showBackground = true, widthDp = 380)
    @Composable
    fun HourlyForecastCardPreview() {
        val sampleHourlyForecasts = remember {
            listOf(
                HourlyForecastItem("11", "ttps://maps.gstatic.com/weather/v1/sunny.png", 70),
                HourlyForecastItem("12", "ttps://maps.gstatic.com/weather/v1/sunny.pngg", 72),
                HourlyForecastItem("13", "https://maps.gstatic.com/weather/v1/sunny.png", 75),
                HourlyForecastItem("14", "https://maps.gstatic.com/weather/v1/sunny.png", 68),
                HourlyForecastItem("15", "ttps://maps.gstatic.com/weather/v1/sunny.png", 65),
                HourlyForecastItem("16", "ttps://maps.gstatic.com/weather/v1/sunny.png", 66),
                HourlyForecastItem("17", "ttps://maps.gstatic.com/weather/v1/sunny.png", 62),
            )
        }
        AtmosphereTheme {
            HourlyForecastCard(hourlyForecasts = sampleHourlyForecasts)
        }
    }

    @Preview(showBackground = true, widthDp = 380)
    @Composable
    fun WeeklyForecastCardPreview() {

        AtmosphereTheme {
            WeeklyForecastList()
        }
    }
    }








